# Forex Demo Trading (Cloud Run)

This package contains a safe demo PHP app for presenting a forex trading UI.

Files:
- forex_demo.php  (demo web app; protected with demo password)
- Dockerfile

Demo password: **demo1234**

## Deploy to Google Cloud Run

1. Enable required services:
   ```
   gcloud services enable run.googleapis.com
   gcloud services enable cloudbuild.googleapis.com
   ```

2. Build container:
   ```
   gcloud builds submit --tag gcr.io/PROJECT_ID/forex-demo
   ```

3. Deploy to Cloud Run:
   ```
   gcloud run deploy forex-demo \
     --image gcr.io/PROJECT_ID/forex-demo \
     --platform managed \
     --region us-central1 \
     --allow-unauthenticated \
     --port 8080
   ```

Replace `PROJECT_ID` with your Google Cloud project ID.

Open the deployed URL and enter the demo password when prompted.

