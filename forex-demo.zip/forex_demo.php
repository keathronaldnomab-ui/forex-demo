<?php
/**
 * forex_demo.php
 * PHP Forex Trading DEMO (Protected by demo password)
 * Demo password: demo1234
 */

session_start();

// Demo password (in production don't hardcode)
$DEMO_PASSWORD = 'demo1234';

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: /");
    exit;
}

// Handle login
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $pw = $_POST['password'] ?? '';
    if ($pw === $DEMO_PASSWORD) {
        $_SESSION['authenticated'] = true;
    } else {
        $loginError = 'Invalid password';
    }
}

// Require authentication
if (empty($_SESSION['authenticated'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head><meta charset="utf-8"><title>Demo Login</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
    body{font-family:Arial,Helvetica,sans-serif;background:#f6f8fa;padding:40px}
    .box{max-width:360px;margin:auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.08)}
    input{width:100%;padding:10px;margin:8px 0;border:1px solid #ddd;border-radius:6px}
    button{width:100%;padding:10px;border:none;border-radius:6px;background:#0066cc;color:#fff;font-size:16px}
    .err{color:#c00;margin-bottom:8px}
    </style>
    </head>
    <body>
    <div class="box">
      <h2>Forex Demo — Login</h2>
      <p>Enter demo password to view the demo.</p>
      <?php if ($loginError): ?><div class="err"><?=htmlspecialchars($loginError)?></div><?php endif; ?>
      <form method="post">
        <input type="password" name="password" placeholder="Demo password" required>
        <input type="hidden" name="action" value="login">
        <button type="submit">Enter Demo</button>
      </form>
      <p style="font-size:12px;color:#666;margin-top:10px">Demo password is provided with the download link.</p>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// ========== Authenticated demo UI ==========
if (!isset($_SESSION['balance'])) {
    $_SESSION['balance'] = 10000.00;
    $_SESSION['history'] = [];
}

function getPrice($symbol) {
    $base = ['EURUSD'=>1.0750, 'GBPUSD'=>1.2450, 'USDJPY'=>150.10];
    $random = rand(-50,50)/10000;
    return $base[$symbol] + $random;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action']=='trade') {
    $symbol = $_POST['symbol'];
    $side   = $_POST['side'];
    $size   = (float) $_POST['size'];
    $price  = getPrice($symbol);
    $pipValue = 10 * $size;
    $profit = ($side === 'buy') ? rand(-20,40) : rand(-40,20);
    $balanceChange = $profit * $pipValue;
    $_SESSION['balance'] += $balanceChange;
    $trade = [
        'time' => date('H:i:s'),
        'symbol' => $symbol,
        'side' => strtoupper($side),
        'price' => number_format($price,5),
        'profit' => number_format($balanceChange,2),
        'balance' => number_format($_SESSION['balance'],2)
    ];
    array_unshift($_SESSION['history'],$trade);
}

$price = getPrice('EURUSD');
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>Forex Trading Demo</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:Arial,Helvetica,sans-serif;background:#f8fafc;margin:20px;color:#222}
.container{max-width:760px;margin:auto;background:#fff;padding:18px;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,0.06)}
h1{color:#0066cc;margin-top:0}
.controls{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.controls select,input{padding:8px;border:1px solid #ddd;border-radius:6px}
button.buy{background:#2ecc71;color:#fff;border:none;padding:10px;border-radius:6px;cursor:pointer}
button.sell{background:#e74c3c;color:#fff;border:none;padding:10px;border-radius:6px;cursor:pointer}
.balance{font-size:18px;margin-bottom:8px}
.price{font-size:20px;color:#0066cc;margin-bottom:8px}
.table{margin-top:14px}
table{width:100%;border-collapse:collapse}
th,td{border:1px solid #eee;padding:8px;text-align:center}
th{background:#fafafa}
.logout{float:right;font-size:14px}
</style>
<script>
setInterval(()=>location.reload(),5000);
</script>
</head>
<body>
<div class="container">
  <a class="logout" href="?logout=1">Logout</a>
  <h1>💹 Forex Demo Trading (Cloud Run)</h1>
  <p><strong>Mode:</strong> Demo simulation — safe for presentation.</p>
  <div class="balance">💰 Balance: <b>$<?php echo number_format($_SESSION['balance'],2); ?></b></div>
  <div class="price">EUR/USD: <b><?php echo number_format($price,5); ?></b></div>

  <form method="post">
    <div class="controls">
      <select name="symbol">
        <option value="EURUSD">EUR/USD</option>
        <option value="GBPUSD">GBP/USD</option>
        <option value="USDJPY">USD/JPY</option>
      </select>
      <input type="number" name="size" step="0.01" min="0.01" value="0.10" required>
      <button class="buy" type="submit" name="side" value="buy" onclick="this.form.action='?';">Buy</button>
      <button class="sell" type="submit" name="side" value="sell" onclick="this.form.action='?';">Sell</button>
      <input type="hidden" name="action" value="trade">
    </div>
  </form>

  <div class="table">
    <h3>📜 Trade History</h3>
    <table>
      <tr><th>Time</th><th>Symbol</th><th>Side</th><th>Price</th><th>P/L ($)</th><th>Balance ($)</th></tr>
      <?php foreach($_SESSION['history'] as $t): ?>
      <tr>
        <td><?=htmlspecialchars($t['time'])?></td>
        <td><?=htmlspecialchars($t['symbol'])?></td>
        <td><?=htmlspecialchars($t['side'])?></td>
        <td><?=htmlspecialchars($t['price'])?></td>
        <td><?=htmlspecialchars($t['profit'])?></td>
        <td><?=htmlspecialchars($t['balance'])?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
</div>
</body>
</html>
